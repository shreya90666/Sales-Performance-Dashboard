"""Validate cleaned Superstore data and a local SQL reconstruction of the model."""
from pathlib import Path
import sqlite3
import math
import pandas as pd

ROOT = Path(__file__).resolve().parent
CSV = ROOT / 'superstore_fixed.csv'
df = pd.read_csv(CSV)
results = []

def check(name, passed, details):
    status = 'PASS' if passed else 'FAIL'
    results.append({'test': name, 'status': status, 'details': details})
    print(f'{status}: {name} - {details}')

check('Unique fact keys', df.Row_ID.is_unique, f'{df.Row_ID.duplicated().sum()} duplicate Row_ID values')
required = ['Row_ID','Order_ID','Order_Date','Customer_ID','Product_ID','Region','Sales','Profit','Quantity','Discount']
missing = int(df[required].isna().sum().sum() + sum(df[c].astype(str).str.strip().eq('').sum() for c in required))
check('Required fields', missing == 0, f'{missing} missing required values; Postal_Code is optional')
# Negative profit is valid; discounts are fractions between zero and one.
valid = (df.Sales.ge(0) & df.Quantity.gt(0) & df.Quantity.mod(1).eq(0) & df.Discount.between(0,1) & df.Ship_Days.ge(0))
check('Valid ranges', valid.all(), f'{(~valid).sum()} invalid rows')

# Recreate the Oracle model locally using SQLite-compatible SQL.
# This does not connect to the live Oracle FreeSQL database.
with sqlite3.connect(':memory:') as db:
    df.to_sql('STG_SUPERSTORE', db, index=False)
    db.execute('CREATE TABLE FACT_SALES AS SELECT Row_ID, Order_ID, Order_Date, Customer_ID, Product_ID, Product_Name, Region, Sales, Profit, Quantity FROM STG_SUPERSTORE')
    dimensions = {'DIM_REGION': ['Region'], 'DIM_DATE': ['Order_Date'], 'DIM_CUSTOMER': ['Customer_ID','Customer_Name','Segment'], 'DIM_PRODUCT': ['Product_ID','Product_Name','Category','Sub_Category']}
    for table, cols in dimensions.items():
        db.execute(f'CREATE TABLE {table} AS SELECT DISTINCT {", ".join(cols)} FROM STG_SUPERSTORE WHERE {cols[0]} IS NOT NULL')
    sales, profit = db.execute('SELECT SUM(Sales), SUM(Profit) FROM FACT_SALES').fetchone()
    match = math.isclose(sales, df.Sales.sum(), abs_tol=0.01, rel_tol=0) and math.isclose(profit, df.Profit.sum(), abs_tol=0.01, rel_tol=0)
    check('Python vs local SQL totals', match, f'Sales={sales:.2f}; Profit={profit:.2f}')
    for table, cols in dimensions.items():
        key = cols[0]
        if table == 'DIM_PRODUCT':
            key = 'Product_ID, Product_Name'
        join = ' AND '.join(
            f'd.{k.strip()}=f.{k.strip()}'
            for k in key.split(',')
        )
        missing = db.execute(f'SELECT COUNT(*) FROM FACT_SALES f WHERE NOT EXISTS (SELECT 1 FROM {table} d WHERE {join})').fetchone()[0]
        check(f'Fact matches {table}', missing == 0, f'{missing} unmatched fact rows')
        duplicates = db.execute(f'SELECT COUNT(*) FROM (SELECT {key} FROM {table} GROUP BY {key} HAVING COUNT(*)>1)').fetchone()[0]
        check(f'Unique join keys in {table}', duplicates == 0, f'{duplicates} ambiguous natural keys')

out = ROOT / 'reports' / 'test_results.csv'
out.parent.mkdir(exist_ok=True)
pd.DataFrame(results).to_csv(out, index=False)
print(f'Report saved: {out}')
raise SystemExit(0 if all(r['status']=='PASS' for r in results) else 1)
